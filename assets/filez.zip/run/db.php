<?php 
  $db_user  = 'if0_36394634';
  $db_pass  = '49DhSvcug8B';
  $db_host  = 'sql309.infinityfree.com';
  $db       = "if0_36394634_imjur";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>
