<?php 
  $db_user  = 'id22080206_assets';
  $db_pass  = 'Chrome57253!*';
  $db_host  = 'localhost';
  $db       = "id22080206_assets";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>